root directory readme
